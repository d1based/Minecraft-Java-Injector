Download Python v3.12 to run the file.

https://www.python.org/downloads/