import tkinter as tk
from tkinter import scrolledtext

class FakeClientApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Minecraft Cheat Client")
        self.root.geometry("600x500")
        self.root.configure(bg="#1e1e1e")  # Light black background
        
        # Remove the title bar
        self.root.overrideredirect(True)
        
        # Track mouse events for dragging
        self.drag_start_x = 0
        self.drag_start_y = 0
        self.root.bind("<Button-1>", self.on_drag_start)
        self.root.bind("<B1-Motion>", self.on_drag_motion)
        
        # Create the close button
        self.close_button = tk.Button(root, text="X", command=self.close_app, font=("Arial", 14, "bold"), bg="#d84f4f", fg="white", relief="flat", borderwidth=0)
        self.close_button.place(x=570, y=10)  # Position it at the top-right corner

        # Configure style
        title_font = ("Arial", 18, "bold")
        button_font = ("Arial", 12)
        label_font = ("Arial", 14)
        console_font = ("Consolas", 12)  # Monospaced font for console

        # Title Label
        self.title_label = tk.Label(root, text="Minecraft Cheat Client", font=title_font, fg="#d8a4ff", bg="#1e1e1e")
        self.title_label.pack(pady=10)
        
        # Status Label
        self.status_label = tk.Label(root, text="Status: Idle", font=label_font, fg="#d8a4ff", bg="#1e1e1e")
        self.status_label.pack(pady=5)
        
        # Action Buttons
        self.start_button = tk.Button(root, text="Activate Cheats", command=self.activate_cheats, font=button_font, bg="#d8a4ff", fg="white", relief="raised", borderwidth=2)
        self.start_button.pack(pady=10, padx=10, fill='x')

        self.stop_button = tk.Button(root, text="Deactivate Cheats", command=self.deactivate_cheats, font=button_font, bg="#d8a4ff", fg="white", relief="raised", borderwidth=2)
        self.stop_button.pack(pady=10, padx=10, fill='x')

        # Options Frame
        self.options_frame = tk.Frame(root, bg="#1e1e1e")
        self.options_frame.pack(pady=10, fill='x')

        # Option Checkboxes
        self.option1 = tk.Checkbutton(self.options_frame, text="Enable Speed Hack", font=button_font, bg="#1e1e1e", fg="#d8a4ff", selectcolor="#333333", highlightthickness=0)
        self.option1.pack(anchor='w', padx=10)

        self.option2 = tk.Checkbutton(self.options_frame, text="Enable Flight", font=button_font, bg="#1e1e1e", fg="#d8a4ff", selectcolor="#333333", highlightthickness=0)
        self.option2.pack(anchor='w', padx=10)

        self.option3 = tk.Checkbutton(self.options_frame, text="Enable X-Ray", font=button_font, bg="#1e1e1e", fg="#d8a4ff", selectcolor="#333333", highlightthickness=0)
        self.option3.pack(anchor='w', padx=10)

        # New Options
        self.esp_option = tk.Checkbutton(self.options_frame, text="Enable ESP", font=button_font, bg="#1e1e1e", fg="#d8a4ff", selectcolor="#333333", highlightthickness=0)
        self.esp_option.pack(anchor='w', padx=10)

        self.aimlock_option = tk.Checkbutton(self.options_frame, text="Enable Aimlock", font=button_font, bg="#1e1e1e", fg="#d8a4ff", selectcolor="#333333", highlightthickness=0)
        self.aimlock_option.pack(anchor='w', padx=10)

        # Apply Button
        self.apply_button = tk.Button(root, text="Apply Settings", command=self.apply_settings, font=button_font, bg="#d8a4ff", fg="white", relief="raised", borderwidth=2)
        self.apply_button.pack(pady=10, padx=10, fill='x')

        # Console-like Log Area
        self.log_area = scrolledtext.ScrolledText(root, height=10, width=80, font=console_font, bg="#000000", fg="#d8a4ff", borderwidth=2, relief="flat")
        self.log_area.pack(pady=10, padx=10, fill='both', expand=True)
        
        # Command Entry
        self.command_entry = tk.Entry(root, font=console_font, bg="#333333", fg="#d8a4ff", insertbackground='white')
        self.command_entry.pack(pady=5, padx=10, fill='x')
        self.command_entry.bind("<Return>", self.execute_command)
        
        # Initial console output
        self.log_area.insert(tk.END, 'print "Inject with Console."\n')
        self.log_area.see(tk.END)  # Scroll to the end of the text

    def on_drag_start(self, event):
        self.drag_start_x = event.x
        self.drag_start_y = event.y

    def on_drag_motion(self, event):
        dx = event.x - self.drag_start_x
        dy = event.y - self.drag_start_y
        new_x = self.root.winfo_x() + dx
        new_y = self.root.winfo_y() + dy
        self.root.geometry(f'+{new_x}+{new_y}')

    def close_app(self):
        self.root.destroy()

    def execute_command(self, event):
        command = self.command_entry.get()
        self.command_entry.delete(0, tk.END)  # Clear the entry field

        if command.startswith("print "):
            # Extract and print the content inside quotes
            try:
                content = command[6:].strip()
                if content.startswith('"') and content.endswith('"'):
                    content = content[1:-1]  # Remove surrounding quotes
                    self.log_area.insert(tk.END, content + '\n')
                else:
                    self.log_area.insert(tk.END, 'Syntax error: Expected quotes around the string.\n')
            except Exception as e:
                self.log_area.insert(tk.END, f'Error: {str(e)}\n')
        else:
            self.log_area.insert(tk.END, 'Unknown command. Only "print" commands are supported.\n')
        
        self.log_area.see(tk.END)  # Scroll to the end of the text

    def activate_cheats(self):
        self.status_label.config(text="Status: Cheats Activated")
        self.log_area.insert(tk.END, "Activating cheats...\n")
        self.root.after(2000, lambda: self.log_area.insert(tk.END, "Cheats activated successfully.\n"))

    def deactivate_cheats(self):
        self.status_label.config(text="Status: Cheats Deactivated")
        self.log_area.insert(tk.END, "Deactivating cheats...\n")
        self.root.after(2000, lambda: self.log_area.insert(tk.END, "Cheats deactivated successfully.\n"))

    def apply_settings(self):
        settings = []
        if self.option1.var.get():
            settings.append("Speed Hack")
        if self.option2.var.get():
            settings.append("Flight")
        if self.option3.var.get():
            settings.append("X-Ray")
        if self.esp_option.var.get():
            settings.append("ESP")
        if self.aimlock_option.var.get():
            settings.append("Aimlock")
        
        if settings:
            self.log_area.insert(tk.END, f"Applying settings: {', '.join(settings)}\n")
            self.root.after(2000, lambda: self.log_area.insert(tk.END, "Settings applied successfully.\n"))
        else:
            self.log_area.insert(tk.END, "No settings selected to apply.\n")

if __name__ == "__main__":
    root = tk.Tk()
    app = FakeClientApp(root)
    root.mainloop()
